class Enti(object):
    def __init__(self, text, category):
        self.text = text
        self.category = category